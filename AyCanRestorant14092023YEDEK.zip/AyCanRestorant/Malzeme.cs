﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AyCanRestorant
{
    public class Malzeme
    {
        public int MALZEMEID {  get; set; }
        public int MALZEMEADEDI {  get; set; }
        public string MALZEMEAD {  get; set; }
        public string MALZEMEBILGISI {  get; set; }


        
    }
}
