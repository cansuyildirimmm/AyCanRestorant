﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AyCanRestorant
{
    public class MalzemeListesi
    {
        public int MALZEMEID { get; set; }
        public string MALZEMEAD { get; set; }
        public string MALZEMEBILGISI { get; set; }
        public double MALZEMEADEDI { get; set; }
    }
}
