﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AyCanRestorant
{
    internal class YemekListesi
    {

        public int YEMEKID { get; set; }
        public string YEMEKADI { get; set; }
        public string ACIKLAMA { get; set; }
        public decimal FIYAT { get; set; }
       
    }
}
