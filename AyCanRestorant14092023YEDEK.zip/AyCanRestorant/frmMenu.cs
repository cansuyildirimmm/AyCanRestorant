﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AyCanRestorant
{
    public partial class frmMenu : Form
    {
        List<MalzemeListesi> malzemeListesi = new List<MalzemeListesi>();

        public frmMenu()
        {

            InitializeComponent();
        }

        private void frmMenu_Load(object sender, EventArgs e)
        {
            string sql = string.Format("SELECT * FROM MALZEMELISTESI");

            using (SqlCommand cmd = new SqlCommand(sql, SQLConnection.Run()))
            {
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        MalzemeListesi malzeme = new MalzemeListesi();

                        malzeme.MALZEMEID = Convert.ToInt32(dr["MALZEMEID"]);
                        malzeme.MALZEMEAD = dr["MALZEMEAD"].ToString();
                        malzeme.MALZEMEBILGISI = dr["MALZEMEBILGISI"].ToString();
                        malzeme.MALZEMEADEDI = Convert.ToDouble(dr["MALZEMEADEDI"]);

                        malzemeListesi.Add(malzeme);
                    }
                }
            }

            dataGridView1.DataSource = malzemeListesi;
        }
    }
}
